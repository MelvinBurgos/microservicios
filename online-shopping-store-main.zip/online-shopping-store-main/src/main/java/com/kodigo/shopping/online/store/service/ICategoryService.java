package com.kodigo.shopping.online.store.service;

import com.kodigo.shopping.online.store.models.Category;

public interface ICategoryService extends CrudGenericService<Category, Long> {
}
