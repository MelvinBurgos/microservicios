package com.kodigo.shopping.online.store.util;

public enum ETypeRating {
    POSITIVE,
    NEGATIVE
}
