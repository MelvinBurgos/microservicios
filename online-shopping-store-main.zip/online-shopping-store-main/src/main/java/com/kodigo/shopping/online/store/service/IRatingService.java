package com.kodigo.shopping.online.store.service;

import com.kodigo.shopping.online.store.models.Rating;

public interface IRatingService extends CrudGenericService<Rating, Long>{
}
