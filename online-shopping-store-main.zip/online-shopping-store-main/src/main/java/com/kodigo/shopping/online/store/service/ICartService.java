package com.kodigo.shopping.online.store.service;

import com.kodigo.shopping.online.store.models.Cart;

public interface ICartService extends CrudGenericService<Cart, Long>{
}
