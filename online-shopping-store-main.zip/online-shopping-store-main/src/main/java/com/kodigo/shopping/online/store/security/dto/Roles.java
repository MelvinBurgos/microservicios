package com.kodigo.shopping.online.store.security.dto;

public enum Roles {
    Admin, Guest
}
