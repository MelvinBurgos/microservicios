package com.kodigo.shopping.online.store.service;

import com.kodigo.shopping.online.store.models.Rol;

public interface IRolService extends CrudGenericService<Rol, Long>{
}
