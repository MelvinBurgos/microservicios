package com.kodigo.shopping.online.store.security.dto;

import lombok.Data;

@Data
public class AuthenticationRequest {

    private String userName;
    private String password;
}
