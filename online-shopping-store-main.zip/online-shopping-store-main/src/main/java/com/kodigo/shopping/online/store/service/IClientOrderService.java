package com.kodigo.shopping.online.store.service;

import com.kodigo.shopping.online.store.models.ClientOrder;

public interface IClientOrderService extends CrudGenericService<ClientOrder, Long> {
}
