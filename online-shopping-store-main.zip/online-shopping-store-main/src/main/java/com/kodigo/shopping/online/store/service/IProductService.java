package com.kodigo.shopping.online.store.service;

import com.kodigo.shopping.online.store.models.Product;

public interface IProductService extends CrudGenericService<Product, Long> {
}
