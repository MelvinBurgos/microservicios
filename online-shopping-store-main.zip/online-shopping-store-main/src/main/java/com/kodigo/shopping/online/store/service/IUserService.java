package com.kodigo.shopping.online.store.service;

import com.kodigo.shopping.online.store.models.User;

public interface IUserService extends CrudGenericService<User, Long> {
}
